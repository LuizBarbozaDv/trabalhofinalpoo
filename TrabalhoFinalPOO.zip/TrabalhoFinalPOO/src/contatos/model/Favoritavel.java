package contatos.model;

public interface Favoritavel {
    Boolean isFavorito();
    void setFavorito(Boolean favorito);
}
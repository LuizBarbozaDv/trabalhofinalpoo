package main;

import contatos.view.InterfaceAgenda;

public class Main {
    public static void main(String[] args) {
            new InterfaceAgenda().setVisible(true);
        }
    }
